# List of some awesome command line tools 
1. [[lsd]] or [[exa]] : Beautiful alternative to `ls`
2. [[bat]] : Beautiful alternative to `cat`
3. [[fd]] : Alternative to `find`
4. [[ripgrep]] : Alternative to `grep`
5. [[fzf]] : general-purpose command-line fuzzy finder
6. [[jump]] : Quick jump to directories 
7. [[entr]] : run arbitrary commands when files change
8. [[nnn]] : Extremely fast CLI file manager
