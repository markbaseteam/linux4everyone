## Step 1 : Get the `.sh` file of whatever version of Mathematica is to be installed. 

## Step 2 : Create a folder named `mathematica` in your home directory (name could be anything without spaces)

![[IMG_1 1.png]]

## Step 3 : Open the command terminal and `cd` into the folder where Mathematica setup file is kept and type the following command.
```bash
sudo ./fileName.sh
```

Where, `fileName.sh` is the name of the setup file. In the above case, the command would be,

```bash
sudo ./Mathematica_13.sh
```

Now the installation process will start. 

```ad-note
Choose everything as default when any prompt comes up, unless you know what you are doing. 
```

The process will go as follows :

### Verifying Integrity 
#### It might take a couple of minutes depending upon your hardware 

![[IMG_2.png]]

### Installation directory
#### Press ENTER 
This will install Mathematica in `/usr/local/wolfram/Mathematica/13.0`. Remember this path, as you might need this later to manually install packages. 
![[IMG_3.png]]

```ad-note
This will take 10 to 15 mins depending on the hardware. Have patience


```

### Script installation directory 
#### Press ENTER and let it overwrite the folder. This option will only come if you had a different version of Mathematica installed prior to this. Also select `y` for the wolfram system integration.
![[IMG_6.png]]

#### If you do not know about vernier devices, most probably you do not have one, so simply press `n` . 

![[IMG_8.png]]

## Step 4: Now simply search for Mathematica from application menu (press the WIN key) and press ENTER. When the activation page comes up select `other ways to activate`

![[IMG_9 1.png]]

### Choose `Manual Activation`

![[IMG_10 1.png]]

### This page will open up, and you will get an MathID for your machine. 
![[IMG_11.png]]

## Activation

Open the following link in your browser https://ibug.io/blog/2019/05/mathematica-keygen/ and select your product and put your MathID there, and it will give you an Activation key and a password. Use them in the above activation page. 

```ad-important
DO NOT COPY AND PASTE THE ACTIVATION KEY AND PASSWORD. IT MIGHT NOT WORK. INSTEAD TYPE IT OUT BY HAND. ALSO DO NOT REGISTER.  
```

DONE !!!!!
