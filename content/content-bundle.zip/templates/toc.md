```toc
title: Table of Contents
style: number
varied_style: true
```